RAW_POLICIES=$(aws iam list-policies --scope Local --query Policies[].[Arn,PolicyName,DefaultVersionId] --region $1)
POLICIES=$(echo $RAW_POLICIES | tr -d " " | sed 's/\],/\]\n/g')
for POLICY in $POLICIES
   do echo $POLICY | cut -d '"' -f 4
   echo -e "---------------\n"
   aws iam get-policy-version --version-id $(echo $POLICY | cut -d '"' -f 6) --policy-arn $(echo $POLICY | cut -d '"' -f 2)
   echo -e "\n-----------------\n"
done
