#!/bin/bash

# Set the directory to the current directory
directory="."

# Iterate over each file in the folder
for file in "$directory"/*; do
    # Check if the file is a regular file
    if [ -f "$file" ]; then
        # Execute the command on the file and print the result
        echo "Processing file: $file"
        grep "aws:PrincipalOrgID" "$file" | tee -a output.txt
    fi
done

